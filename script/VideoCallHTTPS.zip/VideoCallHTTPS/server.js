//12-07-2023
//Anfinonty''s notes: I didn't make this i combined the following to make it work over https: XDD
//
//after git clone: npm install
//
//for https:
//cd cert
//openssl req  -nodes -new -x509  -keyout key.pem -out cert.pem
//cd ..
//
//
//Resources
// video call: https://github.com/Abhishek07Kalra/VideoCall
//             https://www.geeksforgeeks.org/how-to-make-a-video-call-app-in-node-js/
// for https to work: https://raw.githubusercontent.com/cracker0dks/nodeJsVoip/master/doc/audioPipeline.png (server.js)


var fs = require('fs');
const express = require('express');
var https = require('https');
const app = express();

//HTTPS
var SSLPORT = 443; //Default 443
var HTTPPORT = 80; //Default 80 (Only used to redirect to SSL port)
var privateKeyPath = "./cert/key.pem"; //Default "./cert/key.pem"
var certificatePath = "./cert/cert.pem"; //Default "./cert/cert.pem"

var privateKey = fs.readFileSync( privateKeyPath );
var certificate = fs.readFileSync( certificatePath );


var server = https.createServer({
    key: privateKey,
    cert: certificate
}, app).listen(SSLPORT);
//

const {v4:uuidv4} = require('uuid');
const {ExpressPeerServer} = require('peer')

const peer = ExpressPeerServer(server , {
  debug:true
});

const io = require('socket.io')(server);

app.use('/peerjs', peer);
app.set('view engine', 'ejs')
app.use(express.static('public'))
app.get('/' , (req,res)=>{
  res.send(uuidv4());
});
app.get('/:room' , (req,res)=>{
    res.render('index' , {RoomId:req.params.room});
});
io.on("connection" , (socket)=>{
  socket.on('newUser' , (id , room)=>{
    socket.join(room);
    socket.to(room).broadcast.emit('userJoined' , id);
    socket.on('disconnect' , ()=>{
        socket.to(room).broadcast.emit('userDisconnect' , id);
    })
  })
})


// Redirect from http to https
var http = require('http');
http.createServer(function (req, res) {
    res.writeHead(301, { "Location": "https://" + req.headers['host'] + ":"+ SSLPORT + "" + req.url });
    res.end();
}).listen(HTTPPORT);

console.log("Webserver & Socketserver running on port: "+ SSLPORT+ " and "+ HTTPPORT);


